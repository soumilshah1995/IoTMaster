import setuptools

setuptools.setup(
    name="iot",
    version="0.0.1",
    author="Example Author",
    author_email="soushah@my.bridgeport.edu",
    description="upload data on any cloud server ",
    url="https://github.com/soumilshah1995/IoTMaster",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
